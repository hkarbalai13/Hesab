package com.filterhesab.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import android.net.Uri;
import android.util.Base64;
import android.os.StrictMode;
import java.io.*;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b); StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); WebView w=new WebView(this); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); w.addJavascriptInterface(new ShareBridge(this),"AndroidShare"); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
  public static class ShareBridge { private final Activity a; ShareBridge(Activity a){this.a=a;}
    @JavascriptInterface public void shareSvg(String base64){ try{byte[] data=Base64.decode(base64,Base64.DEFAULT); File f=new File(a.getCacheDir(),"filter-hesab-report.svg"); try(FileOutputStream o=new FileOutputStream(f)){o.write(data);} Uri uri=Uri.fromFile(f); Intent i=new Intent(Intent.ACTION_SEND); i.setType("image/svg+xml"); i.putExtra(Intent.EXTRA_STREAM,uri); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); a.startActivity(Intent.createChooser(i,"اشتراک‌گذاری گزارش")); }catch(Exception e){android.widget.Toast.makeText(a,"خطا در اشتراک‌گذاری",android.widget.Toast.LENGTH_SHORT).show();}}
  }
}
