plugins {
    id("com.android.application")
}
android {
    namespace = "com.filterhesab.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.filterhesab.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}
